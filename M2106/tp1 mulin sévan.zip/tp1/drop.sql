-- triggers TP3

-- procédures TP2

-- vues TP1 

-- tables initiales 
drop table if exists RESULTAT;
drop table if exists REGATE;
drop table if exists EQUIPAGE;
drop table if exists CHEFDEBORD;
drop table if exists LOUEUR;
drop table if exists PROPRIETAIRE;
drop table if exists AGENCE;
drop table if exists COTISATION;
drop table if exists ACTIVITE;
drop table if exists BATEAU;
drop table if exists ADHERENT;








